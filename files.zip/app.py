import streamlit as st
import numpy as np
import pickle
import os
import warnings
warnings.filterwarnings("ignore")

# ── Page Config ────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Parkinson's Detection",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ── Custom CSS ─────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap');

html, body, [class*="css"] {
    font-family: 'DM Sans', sans-serif;
    background-color: #0a0e1a;
    color: #e8eaf0;
}
.stApp {
    background: linear-gradient(135deg, #0a0e1a 0%, #0d1526 50%, #0a0e1a 100%);
}
h1, h2, h3 { font-family: 'Syne', sans-serif; }

.hero-title {
    font-family: 'Syne', sans-serif;
    font-size: 3rem;
    font-weight: 800;
    background: linear-gradient(135deg, #60a5fa, #a78bfa, #f472b6);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    line-height: 1.1;
    margin-bottom: 0.3rem;
}
.hero-sub {
    font-size: 1rem;
    color: #94a3b8;
    margin-bottom: 2rem;
    font-weight: 300;
}
.card {
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 16px;
    padding: 1.6rem;
    margin-bottom: 1rem;
}
.card-title {
    font-family: 'Syne', sans-serif;
    font-size: 0.85rem;
    font-weight: 700;
    color: #60a5fa;
    text-transform: uppercase;
    letter-spacing: 0.12em;
    margin-bottom: 0.8rem;
}
.step-pill {
    display: inline-block;
    background: rgba(96,165,250,0.1);
    border: 1px solid rgba(96,165,250,0.25);
    border-radius: 999px;
    padding: 0.25rem 0.85rem;
    font-size: 0.78rem;
    font-weight: 600;
    color: #60a5fa;
    margin-bottom: 0.8rem;
}
.result-positive {
    background: linear-gradient(135deg, rgba(239,68,68,0.12), rgba(239,68,68,0.04));
    border: 1px solid rgba(239,68,68,0.35);
    border-radius: 16px;
    padding: 2rem;
    text-align: center;
}
.result-negative {
    background: linear-gradient(135deg, rgba(34,197,94,0.12), rgba(34,197,94,0.04));
    border: 1px solid rgba(34,197,94,0.35);
    border-radius: 16px;
    padding: 2rem;
    text-align: center;
}
.result-title {
    font-family: 'Syne', sans-serif;
    font-size: 1.9rem;
    font-weight: 800;
    margin-bottom: 0.4rem;
}
.result-sub { font-size: 0.9rem; color: #94a3b8; }
.divider { border: none; border-top: 1px solid rgba(255,255,255,0.07); margin: 1.5rem 0; }
.conf-bar-bg {
    background: rgba(255,255,255,0.08);
    border-radius: 999px;
    height: 7px;
    margin: 3px 0 10px 0;
    overflow: hidden;
}
.disclaimer {
    background: rgba(251,191,36,0.07);
    border: 1px solid rgba(251,191,36,0.22);
    border-radius: 10px;
    padding: 0.85rem 1.1rem;
    font-size: 0.81rem;
    color: #fbbf24;
    margin-top: 1.5rem;
}
.stButton > button {
    background: linear-gradient(135deg, #3b82f6, #8b5cf6) !important;
    color: white !important;
    border: none !important;
    border-radius: 12px !important;
    padding: 0.75rem 2rem !important;
    font-family: 'Syne', sans-serif !important;
    font-weight: 700 !important;
    font-size: 1rem !important;
    width: 100% !important;
}
.stButton > button:hover { opacity: 0.85 !important; }
</style>
""", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
#  STAGE INFO
# ══════════════════════════════════════════════════════════════════════════════
STAGES = {
    0: {"label": "Healthy",                "color": "#22c55e", "icon": "✅",
        "desc": "No signs of Parkinson's disease detected."},
    1: {"label": "Stage 1 — Mild",         "color": "#84cc16", "icon": "🟢",
        "desc": "Symptoms on one side only. Daily activities largely unaffected."},
    2: {"label": "Stage 2 — Mild Bilateral","color": "#facc15", "icon": "🟡",
        "desc": "Symptoms on both sides. Balance still relatively maintained."},
    3: {"label": "Stage 3 — Moderate",     "color": "#f97316", "icon": "🟠",
        "desc": "Noticeable balance issues. Mild-to-moderate functional impairment."},
    4: {"label": "Stage 4 — Severe",       "color": "#ef4444", "icon": "🔴",
        "desc": "Severe disability; can still stand/walk without assistance."},
    5: {"label": "Stage 5 — Advanced",     "color": "#9f1239", "icon": "🆘",
        "desc": "Most advanced stage. Requires wheelchair or full-time assistance."},
}


# ══════════════════════════════════════════════════════════════════════════════
#  MODEL LOADING
# ══════════════════════════════════════════════════════════════════════════════
@st.cache_resource
def load_models():
    import tensorflow as tf

    model_files = {
        "cnn":    "cnn_modelfinal.keras",
        "rnn":    "rnn_modelfinal.keras",
        "fusion": "fusion_modelfinal.keras",
    }
    models = {}
    for key, fname in model_files.items():
        if os.path.exists(fname):
            try:
                models[key] = tf.keras.models.load_model(fname)
            except Exception as e:
                models[key] = None
                st.warning(f"⚠️ Could not load {fname}: {e}")
        else:
            models[key] = None

    config = {}
    if os.path.exists("configfinal.pkl"):
        with open("configfinal.pkl", "rb") as f:
            config = pickle.load(f)

    return models, config


# ══════════════════════════════════════════════════════════════════════════════
#  PREPROCESSING  — PIL only, zero cv2
# ══════════════════════════════════════════════════════════════════════════════
def preprocess_image(uploaded_file):
    """Convert spiral image to 128×128 grayscale numpy array using PIL."""
    from PIL import Image
    img = Image.open(uploaded_file).convert("L")
    img = img.resize((128, 128), Image.LANCZOS)
    arr = np.array(img, dtype=np.float32) / 255.0
    return arr.reshape(1, 128, 128, 1)


def preprocess_audio(uploaded_file, config):
    """Extract MFCC + Chroma + Mel features via librosa (no cv2 needed)."""
    import librosa
    import tempfile

    suffix = os.path.splitext(uploaded_file.name)[-1] or ".wav"
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(uploaded_file.read())
        tmp_path = tmp.name

    try:
        y, sr = librosa.load(tmp_path, sr=22050, duration=5.0, mono=True)
    finally:
        os.unlink(tmp_path)

    T = 130

    def fix_len(arr):
        if arr.shape[1] >= T:
            return arr[:, :T]
        return np.pad(arr, ((0, 0), (0, T - arr.shape[1])))

    mfcc   = fix_len(librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13))
    chroma = fix_len(librosa.feature.chroma_stft(y=y, sr=sr))
    mel    = fix_len(librosa.power_to_db(
                 librosa.feature.melspectrogram(y=y, sr=sr, n_mels=40),
                 ref=np.max))

    features = np.concatenate([mfcc, chroma, mel], axis=0).T  # (130, 65)
    return features.astype(np.float32).reshape(1, 130, 65)


# ══════════════════════════════════════════════════════════════════════════════
#  PREDICTION
# ══════════════════════════════════════════════════════════════════════════════
def expand_to_6(probs):
    p = np.array(probs, dtype=np.float32)
    if len(p) == 2:
        pd_prob = float(p[1])
        p = np.array([1 - pd_prob] + [pd_prob / 5] * 5)
    elif len(p) < 6:
        p = np.pad(p, (0, 6 - len(p)))
    else:
        p = p[:6]
    s = p.sum()
    return p / s if s > 0 else p


def run_prediction(models, img_arr, audio_arr):
    cnn_p = rnn_p = fusion_p = None

    if models.get("cnn"):
        try:
            cnn_p = expand_to_6(models["cnn"].predict(img_arr, verbose=0)[0])
        except Exception as e:
            st.warning(f"CNN error: {e}")

    if models.get("rnn"):
        try:
            rnn_p = expand_to_6(models["rnn"].predict(audio_arr, verbose=0)[0])
        except Exception as e:
            st.warning(f"RNN error: {e}")

    if models.get("fusion"):
        try:
            fusion_p = expand_to_6(
                models["fusion"].predict([img_arr, audio_arr], verbose=0)[0]
            )
        except Exception as e:
            st.warning(f"Fusion error: {e}")

    available = [p for p in [fusion_p, cnn_p, rnn_p] if p is not None]
    if not available:
        return None, None, None, None, None

    final = fusion_p if fusion_p is not None else np.mean(available, axis=0)
    stage = int(np.argmax(final))
    conf  = float(final[stage])
    return stage, conf, cnn_p, rnn_p, fusion_p


# ══════════════════════════════════════════════════════════════════════════════
#  UI
# ══════════════════════════════════════════════════════════════════════════════

st.markdown("""
<div style="padding:2.5rem 0 1rem 0;">
  <div class="hero-title">Parkinson's Disease<br>Detection System</div>
  <div class="hero-sub">
    Multimodal Deep Learning &nbsp;·&nbsp;
    CNN (Spiral Handwriting) + RNN (Voice Analysis)
  </div>
</div>
""", unsafe_allow_html=True)
st.markdown('<hr class="divider">', unsafe_allow_html=True)

# Load models
with st.spinner("Loading models…"):
    models, config = load_models()

loaded_names = [k.upper() for k, v in models.items() if v is not None]
if loaded_names:
    st.success(f"✅ Models loaded: {', '.join(loaded_names)}")
else:
    st.error(
        "⚠️ No .keras model files found. Make sure cnn_modelfinal.keras, "
        "rnn_modelfinal.keras, and fusion_modelfinal.keras are in the same "
        "folder as app.py and run: streamlit run app.py from that folder."
    )

st.markdown("")

# ── Input columns ──────────────────────────────────────────────────────────────
col1, col2 = st.columns(2, gap="large")

with col1:
    st.markdown("""
    <div class="card">
      <div class="step-pill">Step 1</div>
      <div class="card-title">🖊️ Spiral Handwriting</div>
      <p style="color:#94a3b8;font-size:0.88rem;margin:0;">
        Draw a spiral on paper, photograph it, and upload below (JPG / PNG).
      </p>
    </div>""", unsafe_allow_html=True)

    image_file = st.file_uploader(
        "Upload Spiral Image",
        type=["jpg", "jpeg", "png", "bmp", "tiff"],
        label_visibility="collapsed",
        key="img_up"
    )
    if image_file:
        st.image(image_file, caption="Uploaded Spiral", use_container_width=True)

with col2:
    st.markdown("""
    <div class="card">
      <div class="step-pill">Step 2</div>
      <div class="card-title">🎙️ Voice Recording</div>
      <p style="color:#94a3b8;font-size:0.88rem;margin:0;">
        Upload a WAV / MP3 voice sample (5–10 sec). Sustain "Aaah" steadily.
      </p>
    </div>""", unsafe_allow_html=True)

    audio_file = st.file_uploader(
        "Upload Voice File",
        type=["wav", "mp3", "ogg", "m4a", "flac"],
        label_visibility="collapsed",
        key="audio_up"
    )
    if audio_file:
        st.audio(audio_file)

# ── Analyze button ─────────────────────────────────────────────────────────────
st.markdown("")
_, btn_col, _ = st.columns([1, 2, 1])
with btn_col:
    analyze = st.button("🔍 Analyze Now")

# ── Results ────────────────────────────────────────────────────────────────────
if analyze:
    if not image_file and not audio_file:
        st.error("Please upload at least one input — spiral image or voice recording.")
    else:
        with st.spinner("Running deep learning analysis…"):
            try:
                img_arr = (preprocess_image(image_file)
                           if image_file
                           else np.zeros((1, 128, 128, 1), dtype=np.float32))

                audio_arr = (preprocess_audio(audio_file, config)
                             if audio_file
                             else np.zeros((1, 130, 65), dtype=np.float32))

                stage, conf, cnn_p, rnn_p, fusion_p = run_prediction(
                    models, img_arr, audio_arr
                )

                if stage is None:
                    st.error("No models are loaded — cannot run prediction.")
                else:
                    info  = STAGES[stage]
                    is_pd = stage > 0

                    st.markdown('<hr class="divider">', unsafe_allow_html=True)
                    st.markdown(
                        "<div style='font-family:Syne,sans-serif;font-size:1.3rem;"
                        "font-weight:800;margin-bottom:1rem;'>📋 Analysis Results</div>",
                        unsafe_allow_html=True
                    )

                    # Main result banner
                    css_cls = "result-positive" if is_pd else "result-negative"
                    st.markdown(f"""
                    <div class="{css_cls}">
                      <div style="font-size:3rem;">{info['icon']}</div>
                      <div class="result-title" style="color:{info['color']};">
                        {"Parkinson's Detected" if is_pd else "No Parkinson's Detected"}
                      </div>
                      <div style="margin:0.5rem 0;">
                        <span style="background:rgba(255,255,255,0.07);
                                     color:{info['color']};
                                     border:1px solid {info['color']}55;
                                     border-radius:999px;
                                     padding:0.3rem 1rem;
                                     font-family:Syne,sans-serif;
                                     font-weight:700;font-size:0.9rem;">
                          {info['label']}
                        </span>
                      </div>
                      <div class="result-sub">{info['desc']}</div>
                    </div>
                    """, unsafe_allow_html=True)

                    st.markdown("")

                    # Confidence metrics
                    m1, m2, m3 = st.columns(3)
                    def metric_card(title, value, color):
                        return (f"<div class='card' style='text-align:center;'>"
                                f"<div class='card-title'>{title}</div>"
                                f"<div style='font-family:Syne,sans-serif;font-size:2.2rem;"
                                f"font-weight:800;color:{color};'>{value}</div></div>")

                    with m1:
                        st.markdown(metric_card("Overall Confidence",
                                    f"{conf*100:.1f}%", info['color']),
                                    unsafe_allow_html=True)
                    with m2:
                        v = f"{float(np.max(cnn_p))*100:.1f}%" if cnn_p is not None else "N/A"
                        st.markdown(metric_card("CNN — Handwriting", v, "#60a5fa"),
                                    unsafe_allow_html=True)
                    with m3:
                        v = f"{float(np.max(rnn_p))*100:.1f}%" if rnn_p is not None else "N/A"
                        st.markdown(metric_card("RNN — Voice", v, "#a78bfa"),
                                    unsafe_allow_html=True)

                    # Stage probability distribution
                    best = (fusion_p if fusion_p is not None
                            else np.mean([p for p in [cnn_p, rnn_p]
                                          if p is not None], axis=0))

                    st.markdown("<div class='card'><div class='card-title'>"
                                "Stage Probability Distribution</div>",
                                unsafe_allow_html=True)

                    for prob, s in zip(best, STAGES.values()):
                        w = max(1, int(prob * 100))
                        st.markdown(f"""
                        <div style="margin-bottom:0.5rem;">
                          <div style="display:flex;justify-content:space-between;
                                      font-size:0.82rem;color:#94a3b8;margin-bottom:2px;">
                            <span>{s['icon']} {s['label']}</span>
                            <span style="color:{s['color']};font-weight:600;">
                              {prob*100:.1f}%
                            </span>
                          </div>
                          <div class="conf-bar-bg">
                            <div style="width:{w}%;height:7px;border-radius:999px;
                                        background:linear-gradient(90deg,
                                          {s['color']}88,{s['color']});"></div>
                          </div>
                        </div>""", unsafe_allow_html=True)

                    st.markdown("</div>", unsafe_allow_html=True)

            except Exception as e:
                st.error(f"❌ Analysis failed: {e}")
                st.exception(e)

# ── Disclaimer ─────────────────────────────────────────────────────────────────
st.markdown("""
<div class="disclaimer">
  ⚠️ <strong>Medical Disclaimer:</strong> This tool is for <strong>research and
  educational purposes only</strong>. It is <strong>not</strong> a substitute for
  professional medical advice, diagnosis, or treatment. Consult a qualified
  neurologist for any medical concerns.
</div>
""", unsafe_allow_html=True)

st.markdown("""
<div style="text-align:center;color:#334155;font-size:0.77rem;
            margin-top:2.5rem;padding-bottom:1rem;">
  Built with TensorFlow · Keras · Streamlit
</div>
""", unsafe_allow_html=True)
